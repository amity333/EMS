package com.cg.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.DTO.Employee;
import com.cg.service.EmployeeService;
import com.cg.service.EmployeeServiceImpl;

/**
 * Servlet implementation class EmployeeServlet
 */
@WebServlet("/EmployeeServlet")
public class EmployeeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	EmployeeService service;
    public EmployeeServlet() {
        super();
        service=new EmployeeServiceImpl();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		HttpSession session=request.getSession(true);
		String qstr=request.getParameter("action");
		
		
		
		if("insert".equals(qstr))
		{
			RequestDispatcher dispatch=request.getRequestDispatcher("insert.jsp");
			dispatch.forward(request,  response);
		}
		
		
		
		else if("displayById".equals(qstr))
		{
			
			RequestDispatcher dispatch=request.getRequestDispatcher("searchById.jsp");
			dispatch.forward(request,  response);		
		}
		
	/*	else if("searchById".equals(qstr))
		{
			String empId=request.getParameter("id");
			int eid=Integer.parseInt(empId);
			Employee emp=service.getEmployeeById(eid);
			session.setAttribute("empByID",emp);
			RequestDispatcher dispatch=request.getRequestDispatcher("success.jsp");
			dispatch.forward(request,  response);
		}*/
		
		else if("displayAll".equals(qstr))
		{
			System.out.println("yesssssss!");
			ArrayList<Employee> list=service.getAllEmployees();
			session.setAttribute("emplist", list);
			RequestDispatcher dispatch=request.getRequestDispatcher("searchAll.jsp");
			dispatch.forward(request,  response);
		}
		else if("deleteEmp".equals(qstr))
		{
			int eid=Integer.parseInt(request.getParameter("id"));
			service.delete(eid);
			ArrayList<Employee> list=service.getAllEmployees();
			session.setAttribute("emplist", list);
			RequestDispatcher dispatch=request.getRequestDispatcher("searchAll.jsp");
			dispatch.forward(request,  response);
		}
		else if("updateEmp".equals(qstr))
		{
			
			int eid=Integer.parseInt(request.getParameter("id"));
			Employee emp = service.getEmployeeById(eid);
			session.setAttribute("emp",emp);
			RequestDispatcher dispatch=request.getRequestDispatcher("update.jsp");
			dispatch.forward(request,  response);
			
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		HttpSession session=request.getSession(false);
		String qstr=request.getParameter("action");
		//System.out.println("hello");
		if("insertEmp".equals(qstr))
		{
			System.out.println("hello");
			String name=request.getParameter("eName");
			String addr=request.getParameter("addr");
			String sal=request.getParameter("eSal");
			int eSal=Integer.parseInt(sal);
			
			Employee emp=new Employee();
			emp.setEmpName(name);
			emp.setEmpSal(eSal);
			emp.setEmpAddr(addr);
			Employee ref= service.addEmployee(emp);
			System.out.println(ref.toString());
			if(ref!=null)
			{
				System.out.println("hello");
				session.setAttribute("emp", ref);
				RequestDispatcher dispatch =
		    	request.getRequestDispatcher("InsertSuccess.jsp");
				
		    	dispatch.forward(request, response);
			}
		}
		else if("searchById".equals(qstr))
		{
			System.out.println("in search by id");
			String empId = request.getParameter("id");
			int eId = Integer.parseInt(empId);
			Employee emp = service.getEmployeeById(eId);
			session.setAttribute("empById", emp);
			RequestDispatcher dispatch = 
					request.getRequestDispatcher("success.jsp");
			dispatch.forward(request, response);
		}
		else if("updateEmp".equals(qstr))
		{
			int eid=Integer.parseInt(request.getParameter("eId"));
			String name=request.getParameter("eName");
			String addr=request.getParameter("addr");
			int sal=Integer.parseInt(request.getParameter("eSal"));
			Employee emp = new Employee(eid,name,sal,addr);
			service.update(emp);
			ArrayList<Employee> list=service.getAllEmployees();
			session.setAttribute("emplist", list);
			RequestDispatcher dispatch=request.getRequestDispatcher("searchAll.jsp");
			dispatch.forward(request,  response);
		}
	}

}
